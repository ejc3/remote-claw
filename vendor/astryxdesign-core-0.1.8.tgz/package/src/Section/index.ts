// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports Section component
 * @output Exports Section component and types
 * @position Entry point for @astryxdesign/core/Section module
 *
 * SYNC: When modified, update /packages/core/src/Section/Section.doc.mjs
 */

export {Section} from './Section';
export type {
  SectionProps,
  SectionVariant,
  SectionVariantMap,
} from './Section';
