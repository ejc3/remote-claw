// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input FieldStatus component source
 * @output Exports FieldStatus and related types
 * @position Entry point for @astryxdesign/core/FieldStatus subpath export
 */

export {FieldStatus} from './FieldStatus';
export type {
  FieldStatusProps,
  FieldStatusVariant,
  FieldStatusVariantMap,
} from './FieldStatus';
