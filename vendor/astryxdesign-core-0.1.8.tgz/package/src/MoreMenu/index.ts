// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @output Exports MoreMenu and related types
 * @position Public API entry point
 */

export {MoreMenu, type MoreMenuProps} from './MoreMenu';
