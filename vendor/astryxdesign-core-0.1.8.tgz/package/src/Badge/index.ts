// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports Badge component and types from Badge.tsx
 * @output Exports Badge, BadgeProps, BadgeVariant, BadgeVariantMap
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/Badge/Badge.doc.mjs
 */

export {Badge} from './Badge';
export type {
  BadgeProps,
  BadgeVariant,
  BadgeVariantMap,
} from './Badge';
