// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports CheckboxInput component and types from CheckboxInput.tsx
 * @output Exports CheckboxInput, CheckboxInputProps, CheckboxInputSize
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/CheckboxInput/CheckboxInput.doc.mjs
 */

export {CheckboxInput} from './CheckboxInput';
export type {
  CheckboxInputProps,
  CheckboxInputSize,
} from './CheckboxInput';
