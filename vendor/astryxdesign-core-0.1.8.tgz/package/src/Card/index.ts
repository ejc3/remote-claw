// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports Card component
 * @output Exports Card component and types
 * @position Entry point for @astryxdesign/core/Card module
 *
 * SYNC: When modified, update /packages/core/src/Card/Card.doc.mjs
 */

export {Card} from './Card';
export type {CardProps, CardVariant, SizeValue} from './Card';
