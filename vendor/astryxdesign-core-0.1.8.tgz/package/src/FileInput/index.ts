// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports FileInput component and types from FileInput.tsx
 * @output Exports FileInput, FileInputProps, FileInputStatus, FileInputStatusType
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/FileInput/FileInput.doc.mjs
 */

export {FileInput} from './FileInput';
export type {
  FileInputProps,
  FileInputStatus,
  FileInputStatusType,
} from './FileInput';
