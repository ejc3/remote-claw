// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Token component
 * @output Exports all Token module public API
 * @position Entry point for Token module
 *
 * SYNC: When adding new Token files, update exports here
 */

export {Token} from './Token';
export type {TokenProps, TokenColor, TokenSize} from './Token';
