// Copyright (c) Meta Platforms, Inc. and affiliates.

/**
 * @file index.ts
 * @input Imports Kbd component and types
 * @output Exports public API for @astryxdesign/core Kbd
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 */

export {Kbd} from './Kbd';
export type {KbdProps} from './Kbd';
