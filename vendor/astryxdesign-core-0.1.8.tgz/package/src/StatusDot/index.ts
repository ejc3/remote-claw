// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from StatusDot component
 * @output Exports StatusDot component and related types
 * @position Entry point for StatusDot; re-exported by /packages/core/src/index.ts
 */

export {StatusDot} from './StatusDot';
export type {
  StatusDotProps,
  StatusDotVariant,
  StatusDotVariantMap,
} from './StatusDot';
