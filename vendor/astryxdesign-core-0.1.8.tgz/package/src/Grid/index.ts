// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from Grid.tsx and GridSpan.tsx
 * @output Exports Grid components and types
 * @position Package entry point for Grid
 *
 * SYNC: When modified, update /packages/core/src/Grid/Grid.doc.mjs
 */

export {Grid} from './Grid';
export type {GridProps, GridColumns, GridAlignment} from './Grid';

export {GridSpan} from './GridSpan';
export type {GridSpanProps} from './GridSpan';
