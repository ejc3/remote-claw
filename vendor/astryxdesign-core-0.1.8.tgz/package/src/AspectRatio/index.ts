// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from AspectRatio.tsx
 * @output Exports AspectRatio component and props type
 * @position Package entry point for AspectRatio
 *
 * SYNC: When modified, update /packages/core/src/AspectRatio/AspectRatio.doc.mjs
 */

export {AspectRatio} from './AspectRatio';
export type {
  AspectRatioProps,
  AspectRatioShape,
  AspectRatioFit,
} from './AspectRatio';
