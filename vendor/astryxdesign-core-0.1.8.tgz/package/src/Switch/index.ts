// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from Switch component
 * @output Exports Switch component and related types
 * @position Entry point for Switch; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/Switch/Switch.doc.mjs
 */

export {Switch} from './Switch';
export type {
  SwitchProps,
  SwitchLabelPosition,
  SwitchLabelSpacing,
} from './Switch';
