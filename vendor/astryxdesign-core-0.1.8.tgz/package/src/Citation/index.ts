// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports Citation component and types from Citation.tsx
 * @output Exports Citation, CitationProps, CitationSource
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 */

export {Citation} from './Citation';
export type {CitationProps, CitationSource} from './Citation';
