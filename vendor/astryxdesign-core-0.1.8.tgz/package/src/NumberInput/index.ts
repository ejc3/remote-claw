// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports NumberInput component and types from NumberInput.tsx
 * @output Exports NumberInput, NumberInputProps, NumberInputSize, NumberInputStatus, NumberInputStatusType
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 *
 * SYNC: When modified, update this header and /packages/core/src/NumberInput/NumberInput.doc.mjs
 */

export {NumberInput} from './NumberInput';
export type {
  NumberInputProps,
  NumberInputSize,
  NumberInputStatus,
  NumberInputStatusType,
} from './NumberInput';
