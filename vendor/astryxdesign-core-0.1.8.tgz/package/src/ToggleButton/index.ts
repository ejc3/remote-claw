// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from ToggleButton.tsx and ToggleButtonGroup.tsx
 * @output Exports ToggleButton, ToggleButtonGroup, and types
 * @position Component entry point; re-exported by /packages/core/src/index.ts
 */

export {ToggleButton} from './ToggleButton';
export type {ToggleButtonProps} from './ToggleButton';

export {ToggleButtonGroup} from './ToggleButtonGroup';
export type {
  ToggleButtonGroupProps,
  ToggleButtonGroupSingleProps,
  ToggleButtonGroupMultipleProps,
} from './ToggleButtonGroup';
