// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input DateTimeInput component exports
 * @output Re-exports DateTimeInput and types
 * @position Package entry point for DateTimeInput
 */

export {DateTimeInput} from './DateTimeInput';
export type {
  DateTimeInputProps,
  DateTimeInputSize,
  DateTimeInputHourFormat,
  DateTimeInputTimeIncrement,
  DateTimeInputStatus,
  DateTimeInputStatusType,
  ISODateTimeString,
} from './DateTimeInput';
