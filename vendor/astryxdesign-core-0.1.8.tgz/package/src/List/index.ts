// Copyright (c) Meta Platforms, Inc. and affiliates.

'use client';

/**
 * @file index.ts
 * @input Imports from List.tsx and ListItem.tsx
 * @output Exports List, ListItem components and their props/types
 * @position Package entry point for List
 *
 * SYNC: When modified, update /packages/core/src/List/List.doc.mjs
 */

export {List} from './List';
export type {ListProps, ListStyle, ListDensity} from './List';
export {ListItem} from './ListItem';
export type {ListItemProps} from './ListItem';
